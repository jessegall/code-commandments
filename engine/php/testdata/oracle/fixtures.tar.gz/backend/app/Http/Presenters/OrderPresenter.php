<?php

namespace Shop\Http\Presenters;

use JesseGall\CodeCommandments\Sins\Backend\EnumValueMatch;
use JesseGall\CodeCommandments\Sins\Backend\Spatie\NewDataObject;

use JesseGall\CodeCommandments\Testing\Fixed;
use JesseGall\CodeCommandments\Testing\Sinful;
use Shop\Data\OrderData;
use Shop\Models\Order;

final class OrderPresenter
{
    /**
     * The FIX for {@see legacyPresent()}: the same order presented through the magic factory —
     * `OrderData::from($order)` runs the casts, mappers and validation a raw `new` skips.
     */
    #[Fixed(NewDataObject::class)]
    public function present(Order $order): OrderData
    {
        return OrderData::from($order);
    }

    #[Sinful(NewDataObject::class)]
    public function legacyPresent(Order $order): OrderData
    {
        return new OrderData(
            id: $order->id,
            status: $order->status,
            totalCents: $order->total_cents,
            lines: [],
        );
    }

    public function label(Order $order): string
    {
        return $order->status->label();
    }

    #[Sinful(EnumValueMatch::class)]
    public function badge(Order $order): string
    {
        return match ($order->status->value) {
            'pending' => 'grey',
            'paid' => 'green',
            'shipped' => 'blue',
            'cancelled' => 'red',
            default => 'grey',
        };
    }
}
