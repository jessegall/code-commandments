<?php

namespace Shop\Http\Controllers;

use JesseGall\CodeCommandments\Sins\Backend\FeatureEnvy;
use JesseGall\CodeCommandments\Sins\Backend\Laravel\ModelMutationAtCallSite;
use JesseGall\CodeCommandments\Sins\Backend\Laravel\RawRequestInput;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use JesseGall\CodeCommandments\Testing\Sinful;
use Shop\Http\Requests\CreateOrderRequest;
use Shop\Models\Order;
use Shop\Services\OrderService;

class OrderController extends Controller
{
    public function __construct(private readonly OrderService $orders) {}

    public function store(CreateOrderRequest $request): Order
    {
        return $this->orders->place($request->customerId(), $request->lines());
    }

    #[Sinful(RawRequestInput::class)]
    public function filter(Request $request): array
    {
        $status = $request->input('status');
        $customerId = (int) $request->input('customer_id');

        return Order::query()->where('status', $status)->where('customer_id', $customerId)->get()->all();
    }

    #[Sinful(ModelMutationAtCallSite::class)]
    #[Sinful(FeatureEnvy::class)]
    public function markPaid(Request $request, Order $order): Order
    {
        $order->status = 'paid';
        $order->paid_at = now();
        $order->save();

        return $order;
    }
}
