<?php

declare(strict_types=1);

namespace CodeCommandments\PhpBridge;

use PhpParser\ErrorHandler\Collecting;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitor\NameResolver;
use PhpParser\Parser;
use PhpParser\ParserFactory;

/**
 * One whole stream, header to trailer, for one request.
 */
final readonly class Stream
{
    public const string VERSION = '8.0.0';

    public function __construct(private Request $request) {}

    /**
     * @param  resource  $out
     */
    public function write($out): void
    {
        $files = Sources::in($this->request->paths, $this->request->contents);
        $this->line($out, ['header' => [
            'contract' => 'tree',
            'version' => 5,
            'language' => 'php',
            'bridge' => ['name' => 'php-bridge', 'version' => self::VERSION, 'reads' => true],
            'roots' => $this->request->paths,
        ]]);
        $referenced = [];
        $declared = [];
        $parser = null;
        $written = 0;
        $types = new Types();
        $judged = array_values(array_filter($files, $this->request->judges(...)));
        foreach ($files as $path) {
            $parser ??= (new ParserFactory())->createForNewestSupportedVersion();
            $types->declare($this->read($this->request->contents[$path] ?? (string) file_get_contents($path), $parser, $path)[1], $path);
        }
        $autoload = $this->autoload();
        if ($autoload !== null && $this->loadFailure($autoload) === '') {
            require_once $autoload;
            $types->loadsClasses();
        }
        foreach ($judged as $path) {
            $code = $this->request->contents[$path] ?? (string) file_get_contents($path);
            [, $statements, $errors, $tokens] = $this->read($code, $parser, $path);
            $types->infer($statements, $path);
            $file = $this->parsed($path, $code, $statements, $errors, $tokens, $types);
            $this->line($out, ['file' => $file]);
            $referenced += $file->translator->referenced;
            $declared += $file->translator->declared;
            $written++;
        }
        $this->writeProgram($out, $declared, $referenced);
        $this->line($out, ['trailer' => ['files' => $written]]);
    }

    /**
     * A file parsed with its names resolved: its code, statements, parse errors and tokens. Each file is parsed once to
     * read its declarations and again to translate it, so no more than one file's tree is held at a time.
     *
     * @return array{string, list<\PhpParser\Node>, Collecting, array}
     */
    private function read(string $code, Parser $parser, string $path): array
    {
        $errors = new Collecting();
        $statements = $parser->parse($code, $errors) ?? [];
        $statements = (new NodeTraverser(new NameResolver($errors, ['preserveOriginalNames' => true]), new AnonymousClassNames(basename($path))))->traverse($statements);

        return [$code, $statements, $errors, $parser->getTokens()];
    }

    /**
     * @param  list<\PhpParser\Node>  $statements
     */
    private function parsed(string $path, string $code, array $statements, Collecting $errors, array $tokens, Types $types): ParsedFile
    {
        $translator = new Translator($code, $tokens, $types);
        $root = $translator->file($statements);
        $nodes = $root->numbered();
        $modules = $root->parts['modules'];
        foreach ($errors->getErrors() as $error) {
            $this->recovered($nodes, $error->getAttributes()['startFilePos'] ?? strlen($code));
        }

        return new ParsedFile(
            $path,
            count($errors->getErrors()),
            count($modules) === 1 ? ($modules[0]->facts['name'] ?? null) : null,
            $root->written($translator->line(...)),
            $translator->comments($nodes),
            $translator,
            $translator->types,
            array_merge($types->readSoFar($path), $this->publishing($path)[1]),
            $this->publishing($path)[0],
        );
    }

    /**
     * The package that ships a config file the project holds a copy of, as vendor/<package>/config/<name>.php, and the
     * lock file that says which packages are installed: a published config is read by its package, not the project.
     *
     * @return array{?string, list<string>}
     */
    private function publishing(string $path): array
    {
        if (basename(dirname($path)) !== 'config') {
            return [null, []];
        }
        $root = dirname($path, 2);
        $lock = is_file("{$root}/composer.lock") ? ["{$root}/composer.lock"] : [];
        foreach (glob("{$root}/vendor/*/*/config/".basename($path)) ?: [] as $shipped) {
            return [basename(dirname($shipped, 3)).'/'.basename(dirname($shipped, 2)), $lock];
        }

        return [null, $lock];
    }

    /**
     * Marks the innermost node around a parse error incomplete: the parser dropped what it could not read there, so
     * its roles are unknown rather than empty. Nodes are in pre-order, so the last one holding the offset is innermost.
     *
     * @param  list<TreeNode>  $nodes
     */
    private function recovered(array $nodes, int $offset): void
    {
        $innermost = $nodes[min(1, count($nodes) - 1)];
        foreach ($nodes as $node) {
            if ($node->start <= $offset && $offset < $node->end) {
                $innermost = $node;
            }
        }
        $innermost->facts['incomplete'] = true;
    }

    /**
     * The scanned project's autoloader: the one asked for, else the nearest vendor/autoload.php above the first path.
     */
    private function autoload(): ?string
    {
        if ($this->request->autoload !== null) {
            return $this->request->autoload;
        }
        $folder = $this->nearest('vendor/autoload.php');

        return $folder === null ? null : realpath("{$folder}/vendor/autoload.php");
    }

    /**
     * The nearest folder at or above the first scanned path holding the file, or none anywhere above it.
     */
    private function nearest(string $file): ?string
    {
        $folder = is_dir($this->request->paths[0]) ? $this->request->paths[0] : dirname($this->request->paths[0]);
        while (true) {
            if (is_file("{$folder}/{$file}")) {
                return $folder;
            }
            if (dirname($folder) === $folder) {
                return null;
            }
            $folder = dirname($folder);
        }
    }

    /**
     * Why the project's own loader was not used, for the program line to carry, or none when it was. A project that
     * declares dependencies it has not installed reads no class of a package, so a method a package's interface
     * fixes reads as the class's own and a rule that excuses such a method cannot: the run says so rather than
     * letting the finding look like the rule's mistake. PHP's own declarations are still read either way.
     */
    private function loaderReason(?string $autoload, string $failure, OutsideSymbols $outside): string
    {
        if ($outside->unlisted() === []) {
            return '';
        }
        if ($autoload !== null) {
            return $failure === '' ? '' : "the project's autoloader at {$autoload} does not load here: {$failure}";
        }
        $folder = $this->nearest('composer.json');
        if ($folder === null || ! $this->declaresDependencies("{$folder}/composer.json")) {
            return '';
        }

        return 'composer.json declares dependencies but vendor/autoload.php is not there: run composer install';
    }

    /**
     * Whether the composer.json names a package to install.
     */
    private function declaresDependencies(string $path): bool
    {
        $declared = json_decode((string) file_get_contents($path), true);
        if (! is_array($declared)) {
            return false;
        }
        foreach (['require', 'require-dev'] as $section) {
            if (is_array($declared[$section] ?? null) && $declared[$section] !== []) {
                return true;
            }
        }

        return false;
    }

    /**
     * Why the autoloader does not load on this machine, tried in a PHP of its own, or none when it loads: one that
     * requires a file only another machine has dies where no handler can catch it, and the run then reads PHP's own
     * declarations alone.
     */
    private function loadFailure(string $autoload): string
    {
        static $tried = [];

        return $tried[$autoload] ??= $this->triedLoading($autoload);
    }

    private function triedLoading(string $autoload): string
    {
        $tried = proc_open([PHP_BINARY, '-d', 'display_errors=stderr', '-r', 'require $argv[1];', $autoload], [1 => ['file', PHP_OS_FAMILY === 'Windows' ? 'NUL' : '/dev/null', 'w'], 2 => ['pipe', 'w']], $pipes);
        if ($tried === false) {
            return 'it could not be tried here';
        }
        $failure = trim((string) stream_get_contents($pipes[2]));
        if (proc_close($tried) === 0) {
            return '';
        }
        if ($failure === '') {
            return 'it failed to load';
        }

        return $failure;
    }

    /**
     * The line naming the symbols the written files reach outside them, written after the files; no line when they
     * reach none. A symbol another file of the scan declares is named too, and the reader drops it.
     *
     * @param  resource  $out
     * @param  array<string, mixed>  $declared
     * @param  array<string, mixed>  $referenced
     */
    private function writeProgram($out, array $declared, array $referenced): void
    {
        $autoload = $this->autoload();
        $failure = $autoload === null ? '' : $this->loadFailure($autoload);
        $scanned = array_flip(array_map(static fn (string $path): string => realpath($path) ?: $path, $this->request->paths));
        $outside = new OutsideSymbols($autoload !== null && $failure === '' ? $autoload : null, $declared, $referenced, $scanned);
        $program = array_filter([
            'symbols' => $outside->all(),
            'unreadable' => $outside->unreadable(),
            'loader' => $this->loaderReason($autoload, $failure, $outside),
        ]);
        if ($program !== []) {
            $this->line($out, ['program' => $program]);
        }
    }

    /**
     * @param  resource  $out
     */
    private function line($out, array $object): void
    {
        fwrite($out, $this->encoded($object) . "\n");
    }

    private function encoded(array $object): string
    {
        return json_encode($object, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR);
    }
}
